#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUFSIZE 100

void error_handling(char *message);

int main(int argc, char **argv) {
	int sock;
	char message[BUFSIZE];
	int str_len;
	struct sockaddr_in serv_addr;
	int i;
	if(argc!=3){
		printf("Usage : %s <IP> <port>\n", argv[0]);
		exit(1);
	}

	sock=socket(PF_INET, SOCK_STREAM, 0); 

	if(sock == -1)
		error_handling("socket() error");

	memset(&serv_addr, 0, sizeof(serv_addr)); 
	serv_addr.sin_family=AF_INET; 
	serv_addr.sin_addr.s_addr=inet_addr(argv[1]); 
	serv_addr.sin_port=htons(atoi(argv[2]));

	if(connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr))==-1) 
		error_handling("connect() error!");//connect

	//TODO: send() 10byte * 3 data
	char* line[3];
	line[0] = "0123456789";
	line[1] = "ABCDEFGHIJ";
	line[2] = "KLMNOPQRST";

	for(i = 0; i<3;i++){
		if(send(sock, line[i], 10, 0)<0)
			error_handling("send() error!");//send
		str_len=recv(sock,message, BUFSIZE, 0);
		message[str_len] = 0;
                printf("From Server: %s\n", message);
	}
	while(1) {
		fputs("Input message(q to quit) : ", stdout); 
		fgets(message, BUFSIZE, stdin);

		if(!strcmp(message,"q\n")) break; 
			
		if(send(sock, message, strlen(message), 0)<0)
			error_handling("input send() error!");//send

		str_len=recv(sock, message, BUFSIZE-1, 0);
		message[str_len] = 0;
		printf("From Server: %s", message);
	}

	//
	close(sock);
	return 0; 
}
void error_handling(char *message) {
	fputs(message, stderr); 
	fputc('\n', stderr); 
	exit(1);
}
